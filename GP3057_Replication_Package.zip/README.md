# GP3057 HAMix replication package

Use Python 3.11 or 3.12. From the extracted directory, install the dependencies with
`python -m pip install -r requirements.txt`.

- `python src/revision_checks.py` reproduces the alternative cutoff and equal-weight checks and Tables 5, 6 and 8.
- `python src/analysis_engagement_models.py` fits the models in Tables 3–4 (including the two hurdle stages).
- `python src/analysis_matching.py` runs the 1:1 propensity-score matching used in Table 4.
- `python src/analysis_dimension.py` fits the dimension analysis in Table 7.
- `python src/generate_topconf_figures.py` regenerates grouped plots and their summaries, including Figure 7.

Outputs from the original analysis scripts are written under data/outputs. The negative binomial GLMs use alpha=1. Exact propensity-score ties can affect the order of greedy matches across software versions because the aggregate is a linear combination of the five dimensions. Table 4 records the original matching output. The bundled archived CSVs record the original model and matching estimates for comparison.

The input is a frozen extract of 11,779 answers. Question and author group codes replace URLs and names. Empty author codes share a cluster in the original analysis. The extract omits question titles and answer text. It preserves row order, the original analytic labels, and the original recorded counters. See data_dictionary.txt and scoring_prompt.txt. No scraping or scoring API is needed to reproduce the statistical analysis.
