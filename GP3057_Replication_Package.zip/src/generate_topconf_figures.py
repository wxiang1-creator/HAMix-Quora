from pathlib import Path
from statistics import NormalDist

import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import numpy as np
import pandas as pd
try:
    from scipy.stats import ttest_ind
except Exception:
    ttest_ind = None


PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_PATH = PROJECT_ROOT / "data" / "processed" / "merged.csv"
FIG_DIR = PROJECT_ROOT / "data" / "outputs" / "figures"
TAB_DIR = PROJECT_ROOT / "data" / "outputs" / "descriptive_tables"
FIG_DIR.mkdir(parents=True, exist_ok=True)
TAB_DIR.mkdir(parents=True, exist_ok=True)

COLORS = {
    "Human-like": "#2f5f8f",
    "AI-like": "#c75d2c",
    "Uncertain": "#8a8f98",
    "Neutral": "#4b5563",
}


def setup_style():
    plt.rcParams.update(
        {
            "font.family": "Times New Roman",
            "font.size": 8.5,
            "axes.titlesize": 9.5,
            "axes.labelsize": 8.5,
            "xtick.labelsize": 8,
            "ytick.labelsize": 8,
            "legend.fontsize": 8,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.linewidth": 0.7,
            "grid.color": "#d7dce2",
            "grid.linewidth": 0.45,
            "figure.dpi": 150,
            "savefig.dpi": 600,
        }
    )


def save(fig, name, tight=True):
    png = FIG_DIR / f"{name}.png"
    pdf = FIG_DIR / f"{name}.pdf"
    if tight:
        fig.tight_layout()
    fig.savefig(png, bbox_inches="tight")
    fig.savefig(pdf, bbox_inches="tight")
    plt.close(fig)
    return png, pdf


def load_data():
    df = pd.read_csv(DATA_PATH)
    for col in [
        "engagement",
        "log_engagement",
        "text_len",
        "log_text_len",
        "year",
        "ai_probability",
        "is_ai",
        "score",
        "views",
        "log_views",
    ]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    df["ai_label"] = np.where(
        df["is_ai"] == 1,
        "AI-like",
        np.where(df["is_ai"] == 0, "Human-like", "Uncertain"),
    )
    if "log_engagement" not in df.columns:
        df["log_engagement"] = np.log1p(df["engagement"])
    if "log_text_len" not in df.columns:
        df["log_text_len"] = np.log1p(df["text_len"])
    return df


def ci95(values):
    values = pd.Series(values).dropna()
    if len(values) <= 1:
        return 0.0
    return 1.96 * values.std(ddof=1) / np.sqrt(len(values))


def p_star(p):
    if p < 0.001:
        return "***"
    if p < 0.01:
        return "**"
    if p < 0.05:
        return "*"
    return "n.s."


def p_label(p):
    if not np.isfinite(p):
        return "p=n/a"
    if p < 0.001:
        return "p<.001"
    return f"p={p:.3f}".replace("0.", ".")


def welch_pvalue_approx(a, b):
    a = pd.Series(a).dropna()
    b = pd.Series(b).dropna()
    if len(a) <= 2 or len(b) <= 2:
        return np.nan
    if ttest_ind is not None:
        return float(ttest_ind(a, b, equal_var=False, nan_policy="omit").pvalue)
    se = np.sqrt(a.var(ddof=1) / len(a) + b.var(ddof=1) / len(b))
    if not np.isfinite(se) or se == 0:
        return np.nan
    t_stat = abs((a.mean() - b.mean()) / se)
    return 2 * (1 - NormalDist().cdf(t_stat))


def make_pipeline_figure():
    fig, ax = plt.subplots(figsize=(6.9, 2.35))
    ax.axis("off")

    steps = [
        ("Data crawl", "47,834 raw\nanswers"),
        ("Cleaning", "deduplication\ntext/year filters"),
        ("AI-likeness", "Winston score\n0.8 / 0.2 cutoffs"),
        ("Quality", "5 model-scored\ndimensions"),
        ("Analysis", "OLS/count models\nmatching/checks"),
    ]
    x_positions = np.linspace(0.095, 0.905, len(steps))
    y = 0.61
    box_w = 0.165
    box_h = 0.38

    for i, ((title, subtitle), x) in enumerate(zip(steps, x_positions)):
        rect = Rectangle(
            (x - box_w / 2, y - box_h / 2),
            box_w,
            box_h,
            facecolor="#f7f8fa",
            edgecolor="#374151",
            linewidth=0.8,
            transform=ax.transAxes,
        )
        ax.add_patch(rect)
        ax.text(
            x,
            y + 0.07,
            title,
            ha="center",
            va="center",
            weight="bold",
            transform=ax.transAxes,
            fontsize=7.4,
            clip_on=True,
        )
        ax.text(
            x,
            y - 0.075,
            subtitle,
            ha="center",
            va="center",
            transform=ax.transAxes,
            fontsize=6.8,
            linespacing=1.15,
            clip_on=True,
        )
        if i < len(steps) - 1:
            ax.annotate(
                "",
                xy=(x_positions[i + 1] - box_w / 2 - 0.008, y),
                xytext=(x + box_w / 2 + 0.008, y),
                xycoords=ax.transAxes,
                arrowprops=dict(arrowstyle="->", lw=0.8, color="#374151"),
            )

    ax.add_patch(
        Rectangle(
            (0.055, 0.12),
            0.89,
            0.15,
            facecolor="#f7f8fa",
            edgecolor="#d1d5db",
            linewidth=0.5,
            transform=ax.transAxes,
        )
    )
    ax.text(
        0.5,
        0.195,
        "Controls/checks: text length, year, exposure proxy, quality dimensions, question FE, author-clustered SE, count models, matching",
        ha="center",
        va="center",
        transform=ax.transAxes,
        fontsize=7.1,
        color="#374151",
    )
    save(fig, "topconf_pipeline_workflow")


def make_temporal_combined(df):
    fig, axes = plt.subplots(2, 1, figsize=(6.9, 4.2), gridspec_kw={"height_ratios": [1.0, 1.05]})

    count = df.dropna(subset=["year"]).copy()
    count["year"] = count["year"].astype(int)
    mix = count.groupby(["year", "ai_label"]).size().unstack(fill_value=0)
    mix = mix.reindex(columns=["Human-like", "AI-like", "Uncertain"], fill_value=0)
    share = mix.div(mix.sum(axis=1), axis=0)
    bottom = np.zeros(len(share))
    x = np.arange(len(share.index))
    for label in ["Human-like", "AI-like", "Uncertain"]:
        axes[0].bar(x, share[label], bottom=bottom, color=COLORS[label], width=0.62, label=label)
        bottom += share[label].to_numpy()
    for i, total in enumerate(mix.sum(axis=1)):
        axes[0].text(i, 1.03, f"N={int(total):,}", ha="center", fontsize=7)
    axes[0].set_xticks(x)
    axes[0].set_xticklabels([str(y) for y in share.index])
    axes[0].set_ylim(0, 1.12)
    axes[0].set_ylabel("Share of answers")
    axes[0].set_xlabel("Year")
    axes[0].set_title("(a) Content mix")
    axes[0].legend(loc="center left", bbox_to_anchor=(1.01, 0.5), frameon=False, fontsize=7.4)

    thresholds = [0.2, 0.3, 0.5, 0.7, 0.8]
    temp = df.dropna(subset=["year", "ai_probability"]).copy()
    temp["year"] = temp["year"].astype(int)
    years = sorted(temp["year"].dropna().unique())
    for threshold in thresholds:
        ratio = temp.assign(is_above=temp["ai_probability"] >= threshold).groupby("year")["is_above"].mean()
        lw = 1.8 if threshold == 0.8 else 0.9
        alpha = 1.0 if threshold == 0.8 else 0.55
        ls = "-" if threshold == 0.8 else "--"
        axes[1].plot(ratio.index, ratio.values, marker="o", lw=lw, alpha=alpha, ls=ls, label=f"p >= {threshold}")
    axes[1].axvspan(2025.65, 2026.35, color="#e5e7eb", alpha=0.6)
    axes[1].text(2026, axes[1].get_ylim()[1] * 0.84, "2026\nincomplete", ha="center", fontsize=7, color="#4b5563")
    axes[1].set_xlabel("Year")
    axes[1].set_ylabel("AI-like share")
    axes[1].set_title("(b) Threshold sensitivity")
    axes[1].set_xticks(years)
    axes[1].set_xticklabels([str(y) for y in years])
    axes[1].grid(axis="y")
    axes[1].legend(loc="center left", bbox_to_anchor=(1.01, 0.5), frameon=False, fontsize=7.1)

    fig.subplots_adjust(right=0.78, hspace=0.55)
    save(fig, "topconf_temporal_combined", tight=False)


def make_engagement_longtail(df):
    data = df[df["ai_label"].isin(["Human-like", "AI-like"])].dropna(subset=["log_engagement"])
    fig, axes = plt.subplots(1, 2, figsize=(6.9, 2.55), gridspec_kw={"width_ratios": [1.25, 0.85]})
    bins = np.linspace(0, data["log_engagement"].max(), 45)
    for label in ["Human-like", "AI-like"]:
        vals = data.loc[data["ai_label"] == label, "log_engagement"]
        axes[0].hist(vals, bins=bins, density=True, alpha=0.45, color=COLORS[label], label=label)
    axes[0].set_xlabel("log(1 + engagement)")
    axes[0].set_ylabel("Density")
    axes[0].set_title("(a) Log-scale distribution")
    axes[0].legend(frameon=False)

    vals = [
        data.loc[data["ai_label"] == "Human-like", "log_engagement"],
        data.loc[data["ai_label"] == "AI-like", "log_engagement"],
    ]
    box = axes[1].boxplot(vals, tick_labels=["Human-like", "AI-like"], widths=0.55, showfliers=False, patch_artist=True)
    for patch, label in zip(box["boxes"], ["Human-like", "AI-like"]):
        patch.set_facecolor(COLORS[label])
        patch.set_alpha(0.75)
    axes[1].set_ylabel("log(1 + engagement)")
    axes[1].set_title("(b) Central mass")
    save(fig, "topconf_engagement_longtail")


def make_engagement_by_year(df):
    data = df[df["ai_label"].isin(["Human-like", "AI-like"])].dropna(subset=["year", "log_engagement"]).copy()
    data["year"] = data["year"].astype(int)
    fig, ax = plt.subplots(figsize=(4.9, 2.55))
    for label in ["Human-like", "AI-like"]:
        group = (
            data[data["ai_label"] == label]
            .groupby("year")["log_engagement"]
            .agg(["mean", "count", ci95])
            .rename(columns={"ci95": "ci"})
            .reset_index()
        )
        ax.errorbar(group["year"], group["mean"], yerr=group["ci"], marker="o", capsize=3, lw=1.5, color=COLORS[label], label=label)
        for _, row in group.iterrows():
            ax.text(row["year"], row["mean"] + row["ci"] + 0.03, f"n={int(row['count'])}", ha="center", fontsize=6.6, color=COLORS[label])
    ax.axvspan(2025.65, 2026.35, color="#e5e7eb", alpha=0.6)
    ax.set_xlabel("Year")
    ax.set_ylabel("Mean log(1 + engagement)")
    ax.set_title("Engagement trend by content type")
    ax.grid(axis="y")
    ax.legend(frameon=False)
    save(fig, "topconf_engagement_by_year_ci")


def make_text_length_longtail(df):
    data = df[df["ai_label"].isin(["Human-like", "AI-like"])].dropna(subset=["log_text_len"])
    fig, axes = plt.subplots(1, 2, figsize=(6.9, 2.55), gridspec_kw={"width_ratios": [1.25, 0.85]})
    bins = np.linspace(data["log_text_len"].min(), data["log_text_len"].max(), 45)
    for label in ["Human-like", "AI-like"]:
        vals = data.loc[data["ai_label"] == label, "log_text_len"]
        axes[0].hist(vals, bins=bins, density=True, alpha=0.45, color=COLORS[label], label=label)
    axes[0].set_xlabel("log(1 + text length)")
    axes[0].set_ylabel("Density")
    axes[0].set_title("(a) Log-scale distribution")
    axes[0].legend(frameon=False)

    vals = [
        data.loc[data["ai_label"] == "Human-like", "log_text_len"],
        data.loc[data["ai_label"] == "AI-like", "log_text_len"],
    ]
    box = axes[1].boxplot(vals, tick_labels=["Human-like", "AI-like"], widths=0.55, showfliers=False, patch_artist=True)
    for patch, label in zip(box["boxes"], ["Human-like", "AI-like"]):
        patch.set_facecolor(COLORS[label])
        patch.set_alpha(0.75)
    axes[1].set_ylabel("log(1 + text length)")
    axes[1].set_title("(b) Central mass")
    save(fig, "topconf_text_length_longtail")


def make_text_length_relationship(df):
    data = df[df["ai_label"].isin(["Human-like", "AI-like"])].dropna(subset=["log_text_len", "log_engagement"]).copy()
    data["length_bin"] = pd.qcut(data["text_len"], 6, duplicates="drop")
    rows = []
    for (bin_value, label), group in data.groupby(["length_bin", "ai_label"], observed=True):
        rows.append(
            {
                "bin": str(bin_value),
                "label": label,
                "x": group["log_text_len"].mean(),
                "mean": group["log_engagement"].mean(),
                "ci": ci95(group["log_engagement"]),
                "n": len(group),
            }
        )
    plot = pd.DataFrame(rows)
    fig, ax = plt.subplots(figsize=(4.9, 2.55))
    for label in ["Human-like", "AI-like"]:
        group = plot[plot["label"] == label].sort_values("x")
        ax.errorbar(group["x"], group["mean"], yerr=group["ci"], marker="o", capsize=3, lw=1.5, color=COLORS[label], label=label)
    ax.set_xlabel("Mean log(1 + text length) within bin")
    ax.set_ylabel("Mean log(1 + engagement)")
    ax.set_title("Binned relationship between length and engagement")
    ax.grid(axis="y")
    ax.legend(frameon=False)
    save(fig, "topconf_text_length_relationship")


def make_gap_by_quintile(df, x_col, name, x_label):
    data = df[df["ai_label"].isin(["Human-like", "AI-like"])].dropna(subset=[x_col, "log_engagement"]).copy()
    data["bin"] = pd.qcut(data[x_col], 5, duplicates="drop")
    rows = []
    tests = []
    for bin_idx, (bin_value, gbin) in enumerate(data.groupby("bin", observed=True), start=1):
        ai_vals = gbin.loc[gbin["ai_label"] == "AI-like", "log_engagement"].dropna()
        human_vals = gbin.loc[gbin["ai_label"] == "Human-like", "log_engagement"].dropna()
        p = welch_pvalue_approx(ai_vals, human_vals)
        tests.append({"bin_order": bin_idx, "p": p})
        for label, group in gbin.groupby("ai_label"):
            rows.append(
                {
                    "bin_order": bin_idx,
                    "label": label,
                    "mean": group["log_engagement"].mean(),
                    "ci": ci95(group["log_engagement"]),
                    "n": len(group),
                }
            )
    plot = pd.DataFrame(rows)
    tests = pd.DataFrame(tests)
    plot.to_csv(TAB_DIR / f"{name}_log_engagement_quintile_summary.csv", index=False)
    tests.to_csv(TAB_DIR / f"{name}_log_engagement_quintile_tests.csv", index=False)

    fig, ax = plt.subplots(figsize=(5.45, 2.95))
    ymin = (plot["mean"] - plot["ci"]).min()
    ymax = (plot["mean"] + plot["ci"]).max()
    offsets = {"Human-like": -0.09, "AI-like": 0.09}
    for label in ["Human-like", "AI-like"]:
        group = plot[plot["label"] == label]
        x = group["bin_order"] + offsets[label]
        ax.errorbar(x, group["mean"], yerr=group["ci"], marker="o", capsize=3, lw=1.5, color=COLORS[label], label=label)
        for xx, _, row in zip(x, group["mean"], group.itertuples()):
            if label == "Human-like":
                y_text = row.mean + row.ci + 0.035
                va = "bottom"
            else:
                y_text = row.mean - row.ci - 0.045
                va = "top"
            ax.text(xx, y_text, f"n={row.n}", ha="center", va=va, fontsize=6.1, color=COLORS[label])
    for row in tests.itertuples():
        if pd.notna(row.p):
            ax.text(row.bin_order, ymax + 0.19, p_label(row.p), ha="center", fontsize=6.9, color="#374151")
    ax.set_xticks(range(1, 6))
    ax.set_xticklabels([f"Q{i}" for i in range(1, 6)])
    ax.set_xlabel(x_label)
    ax.set_ylabel("Mean log(1 + engagement)")
    ax.set_ylim(bottom=ymin - 0.18, top=ymax + 0.43)
    ax.set_title(f"Engagement gap across {x_label.lower()}")
    ax.grid(axis="y")
    ax.legend(frameon=False, loc="center left", bbox_to_anchor=(1.01, 0.18))
    fig.subplots_adjust(right=0.78)
    save(fig, f"topconf_{name}_gap_ci_tests", tight=False)


def make_quality_dimension_scores(df):
    dims = [
        ("clarity_score", "Clarity"),
        ("completeness_score", "Completeness"),
        ("relevance_score", "Relevance"),
        ("originality_score", "Originality"),
        ("authenticity_score", "Authenticity"),
    ]
    data = df[df["ai_label"].isin(["Human-like", "AI-like"])].copy()
    rows = []
    for dim_col, dim_label in dims:
        for label, group in data.groupby("ai_label"):
            vals = group[dim_col].dropna()
            rows.append(
                {
                    "dimension": dim_label,
                    "label": label,
                    "mean": vals.mean(),
                    "ci": ci95(vals),
                    "n": len(vals),
                }
            )
    plot = pd.DataFrame(rows)
    plot.to_csv(TAB_DIR / "topconf_quality_dimension_ci.csv", index=False)

    fig, ax = plt.subplots(figsize=(5.55, 2.95))
    y = np.arange(len(dims))
    offsets = {"Human-like": -0.11, "AI-like": 0.11}
    for label in ["Human-like", "AI-like"]:
        group = plot[plot["label"] == label].set_index("dimension").loc[[d[1] for d in dims]].reset_index()
        ypos = y + offsets[label]
        ax.errorbar(
            group["mean"],
            ypos,
            xerr=group["ci"],
            fmt="o",
            linestyle="none",
            capsize=3,
            elinewidth=1.1,
            color=COLORS[label],
            label=label,
        )
    ax.set_yticks(y)
    ax.set_yticklabels([d[1] for d in dims])
    ax.invert_yaxis()
    ax.set_xlabel("Mean quality score (0-1)")
    ax.set_xlim(0, 1)
    ax.set_title("Model-scored quality dimensions with 95% CIs")
    ax.legend(frameon=False, loc="lower right")
    ax.grid(axis="x")
    save(fig, "topconf_quality_dimension_scores_ci")


def main():
    setup_style()
    df = load_data()
    make_pipeline_figure()
    make_temporal_combined(df)
    make_engagement_longtail(df)
    make_engagement_by_year(df)
    make_text_length_longtail(df)
    make_text_length_relationship(df)
    make_gap_by_quintile(df, "text_len", "length_quintile", "Text-length quintile")
    make_quality_dimension_scores(df)
    make_gap_by_quintile(df, "score", "quality_quintile", "Quality-score quintile")
    print("Saved top-conference style figures to", FIG_DIR)


if __name__ == "__main__":
    main()
