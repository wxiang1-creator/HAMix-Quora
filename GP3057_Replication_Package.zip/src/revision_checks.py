import numpy as np
import statsmodels.formula.api as smf
from scipy.stats import ttest_ind
from analysis_utils import DIMENSION_COLS, load_merged_dataset

d = load_merged_dataset()
g = d[d.is_ai.isin([0, 1])].copy()

def compare(label, ai, human):
    print(label, len(ai), len(human), ai.mean() - human.mean(),
          ttest_ind(ai, human, equal_var=False).pvalue)

compare('Primary cutoffs', g[g.is_ai == 1].log_engagement, g[g.is_ai == 0].log_engagement)
compare('Alternative cutoffs', d[d.ai_probability >= .7].log_engagement,
        d[d.ai_probability <= .3].log_engagement)
equal = np.log1p(g.upvotes + g.comments + g.shares)
compare('Equal weights', equal[g.is_ai == 1], equal[g.is_ai == 0])
print(g.groupby('ai_label').text_len.describe())
print(smf.ols('log_engagement ~ text_len', d).fit(cov_type='HC3').summary())
for label, group in g.groupby('ai_label'):
    print(label)
    print(smf.ols('log_engagement ~ ' + ' + '.join(DIMENSION_COLS), group)
          .fit(cov_type='HC3').summary())
